/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.c
 * @brief C programing file that computes some statistics of an array.
 * 
 * A simple C source file that exhibits a handful of basic c-programming
 * features to show how to calculate some statistics on an array:
 *     -Median
 *	   -Mean
 *     -Maximum
 *     -Minimum
 * Also, the input array will be sorted in a descending order and printed out.
 *
 * @author Yoon mo Yang
 * @date May 12th 2019
 */

#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

void main() {

  unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                              114, 88,   45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};

  /* Other Variable Declarations Go Here */
  /* Statistics and Printing Functions Go Here */
  print_statistics(test, SIZE);
  print_array(test, SIZE);

}

int print_statistics(unsigned char * ptr, int N){
	sort_array(ptr, N);
	int _median = find_median(ptr, N);
	int _mean = find_mean(ptr, N);
	int _maximum = find_maximum(ptr);
	int _minimum = find_minimum(ptr, N);
	printf("Median is %d\n", _median);
	printf("Mean is %d\n", _mean);
	printf("Maximum is %d\n", _maximum);
	printf("Minimum is %d\n", _minimum);
	return 0;
}

int print_array(unsigned char * ptr, int N){
	int i = 0;
	printf("data array has: \n");
	for (i=0; i < N; i++){
		printf("%d, ", ptr[i]);
	}
	return 0;
}

int find_median(unsigned char * ptr, int N){
	if (N%2 == 0){
		// if the array has an even legnth, return the mean of the two elements
		// in the middle. 
		return ((ptr[N/2]+ptr[N/2-1])/2);
	}
	else{
		// otherwise just return the middle element.
		return ptr[N/2];
	}
}

int find_mean(unsigned char * ptr, int N){
	int sum = 0;
	int i = 0;
	for (i = 0; i < N; i++){
		sum +=ptr[i];
	}
	return sum/N;
}

int find_maximum(unsigned char * ptr){

	return ptr[0];
}

int find_minimum(unsigned char * ptr,int N){
	return ptr[N-1];
}

void sort_array(unsigned char * ptr, int N){
	int i = 0;
	int j = 0;
	int tmp = 0;
	for (i = 0; i < N; i++){
		for (j = 0; j < N; j++){
			if (ptr[j] < ptr[i])             
			{
				tmp = ptr[i];        
				ptr[i] = ptr[j];        
				ptr[j] = tmp;             
			}
		}
	}
}
