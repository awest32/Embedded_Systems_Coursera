/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * @file stats.h 
 *
 * @brief a header file for stats.c
 *
 * @author Yoon mo Yang
 * @date May 12th 2019
 */
#ifndef __STATS_H__
#define __STATS_H__

/* Add Your Declarations and Function Comments here */ 
int print_statistics(unsigned char * ptr, int N);
/**
 * @brief: A function that prints the statistics of an array including 
 *         minimum, maximum, mean, and median.
 * @param: 
 *		int * ptr: Pointer to an array
 * 		int N: length of an array
 * @return:
 *		None; it only print outs the statistics of an array.
 */

int print_array(unsigned char * ptr, int N);
/**
 * @brief: Given an array of data and a length, 
 *		   prints the array to the screen
 * @param: 
 *		int * ptr: Pointer to an array
 * 		int N: length of an array
 * @return:
 *		None; it only print outs an array.
 */
int find_median(unsigned char * ptr, int N);
/**
 * @brief: Given an array of data and a length, 
 *	       returns the median value
 * @param: 
 *		int * ptr: Pointer to an array
 * 		int N: length of an array
 * @return:
 *		median of an array.
 */
int find_mean(unsigned char * ptr, int N);
/**
 * @brief: Given an array of data and a length, 
 *	       returns the median value
 * @param: 
 *		int * ptr: Pointer to an array
 * 		int N: length of an array
 * @return:
 *		mean of an array.
 */
int find_maximum(unsigned char * ptr);
/**
 * @brief: Given an array of data and a length, 
 *         returns the maximum
 * @param: 
 *		int * ptr: Pointer to an array
 * @return:
 *		maximum of an array.
 */
int find_minimum(unsigned char * ptr, int N);
/**
 * @brief: Given an array of data and a length, 
 *         returns the minimum
 * @param: 
 *		int * ptr: Pointer to an array
 * 		int N: length of an array
 * @return:
 *		minimum of an array.
 */
void sort_array(unsigned char * ptr, int N);
/**
 * @brief: Given an array of data and a length, sorts the array from largest to smallest. 
 *         (The zeroth Element should be the largest value, 
 *         and the last element (n-1) should be the smallest value.)
 * @param: 
 *		int * ptr: Pointer to an array
 * 		int N: length of an array
 * @return:
 *		None; it only sorts an array.
 */
#endif /* __STATS_H__ */

