Cousera: Introduction to Embedded Systems Software and Development Environments


1st Week Assignment Description: <br/>
This assignment contains two files: stats.c and stats.h <br/>
stats.c contains a couple of functions that can analyze an array of unsigned char data items and report analytics on the maximum, minimum, mean, and median of the data set. In addition, this data set will be reordered from large to small. All statistics will be rounded down to the nearest integer. After analysis and sorting is done, data will be printed out to the screen in nicely formatted presentation. 

Written by Mahmoud Sayed	
Date: july 2nd 2019
