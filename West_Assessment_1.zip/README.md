/*Author: Amanda West
Date: 07/13/2019
Description: This project takes in an unsigned char array and an unsigned integer. It outputs the sorted array and some parameters from the array to the screen. The array parameters are the mean, median, minimum, and maximum.*/
